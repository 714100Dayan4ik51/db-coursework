﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Realty
{
    public partial class FormClient : Form
    {
        int role;
        private int userId;
        private int _userId;
        SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionRealty);

        public FormClient(int numb, int user_id)
        {
            InitializeComponent();
            this.role = numb;
            this.userId = user_id;
            this.connection = connection;
            LoadUserData(userId);
            _userId = user_id;
        }

        private void test_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "estateAgencyDataSet13.RealtyView". При необходимости она может быть перемещена или удалена.
            this.realtyViewTableAdapter5.Fill(this.estateAgencyDataSet13.RealtyView);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "estateAgencyDataSet10.RealtyView". При необходимости она может быть перемещена или удалена.
            this.realtyViewTableAdapter4.Fill(this.estateAgencyDataSet10.RealtyView);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "estateAgencyDataSet6.RealtyView". При необходимости она может быть перемещена или удалена.
            this.realtyViewTableAdapter3.Fill(this.estateAgencyDataSet6.RealtyView);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "estateAgencyDataSet3.RealtyView". При необходимости она может быть перемещена или удалена.
            this.realtyViewTableAdapter2.Fill(this.estateAgencyDataSet3.RealtyView);
            FillComboBoxes();
            LoadUserData(_userId);
            LoadFavorites();
            ViewOrderHistory();
            comboBoxPropertyType.SelectedIndexChanged += FilterData;
            comboBoxPrice.SelectedIndexChanged += FilterData;
            comboBoxRoomCount.SelectedIndexChanged += FilterData;
            comboBoxCity.SelectedIndexChanged += FilterData;
            SearchTb.TextChanged += FilterData;
            // TODO: данная строка кода позволяет загрузить данные в таблицу "estateAgencyDataSet2.RealtyView". При необходимости она может быть перемещена или удалена.
            this.realtyViewTableAdapter1.Fill(this.estateAgencyDataSet2.RealtyView);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "estateAgencyDataSet1.RealtyView". При необходимости она может быть перемещена или удалена.
            //this.realtyViewTableAdapter.Fill(this.estateAgencyDataSet1.RealtyView);

            dataGridViewRealty.ContextMenuStrip = contextMenuStrip1;
        }

        private void LoadUserData(int userId)
        {
            string query = "SELECT surname, name, patronymic, login, phone FROM [dbo].[User] WHERE user_id = @UserId";

            try
            {
                using (SqlConnection conn = new SqlConnection(Properties.Settings.Default.connectionRealty))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@UserId", userId);

                    connection.Open();

                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        // Заполняем TextBox значениями из базы данных
                        SurnameTb.Text = reader["surname"].ToString();
                        NameTb.Text = reader["name"].ToString();
                        PatronymicTb.Text = reader["patronymic"].ToString();
                        EmailTb.Text = reader["login"].ToString();
                        PhoneTb.Text = reader["phone"].ToString();
                    }

                    reader.Close();
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке данных: " + ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            richTextBox1.Text = dataGridViewRealty.CurrentRow.Cells[4].Value.ToString();
            textBox1.Text = dataGridViewRealty.CurrentRow.Cells[0].Value.ToString();
            textBox2.Text = dataGridViewRealty.CurrentRow.Cells[6].Value.ToString();
            textBox3.Text = dataGridViewRealty.CurrentRow.Cells[5].Value.ToString();
            textBox4.Text = dataGridViewRealty.CurrentRow.Cells[3].Value.ToString();
        }

        private void FillComboBoxes()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionRealty))
                {
                    connection.Open();

                    // Заполнение ComboBox для типа недвижимости
                    comboBoxPropertyType.Items.Clear();
                    comboBoxPropertyType.Items.Add("Все"); // Пустое значение
                    SqlCommand cmdType = new SqlCommand("SELECT DISTINCT type_name FROM RealtyView", connection);
                    SqlDataReader readerType = cmdType.ExecuteReader();
                    while (readerType.Read())
                    {
                        comboBoxPropertyType.Items.Add(readerType["type_name"].ToString());
                    }
                    readerType.Close();

                    // Заполнение ComboBox для диапазонов количества комнат
                    comboBoxRoomCount.Items.Clear();
                    comboBoxRoomCount.Items.Add("Все"); // Пустое значение
                    comboBoxRoomCount.Items.Add("1 комната");
                    comboBoxRoomCount.Items.Add("1-3 комнаты");
                    comboBoxRoomCount.Items.Add("4-5 комнат");
                    comboBoxRoomCount.Items.Add("Более 5 комнат");

                    // Заполнение ComboBox для диапазонов цены
                    comboBoxPrice.Items.Clear();
                    comboBoxPrice.Items.Add("Все"); // Пустое значение
                    comboBoxPrice.Items.Add("До 1 млн");
                    comboBoxPrice.Items.Add("От 1 млн до 5 млн");
                    comboBoxPrice.Items.Add("От 5 млн до 10 млн");
                    comboBoxPrice.Items.Add("Более 10 млн");

                    // Заполнение ComboBox для городов
                    comboBoxCity.Items.Clear();
                    comboBoxCity.Items.Add("Все"); // Пустое значение
                    SqlCommand cmdCity = new SqlCommand("SELECT DISTINCT city_name FROM RealtyView", connection);
                    SqlDataReader readerCity = cmdCity.ExecuteReader();
                    while (readerCity.Read())
                    {
                        comboBoxCity.Items.Add(readerCity["city_name"].ToString());
                    }
                    readerCity.Close();

                    // Устанавливаем начальный выбор на "Все" для сброса фильтра
                    comboBoxPropertyType.SelectedIndex = 0;
                    comboBoxRoomCount.SelectedIndex = 0;
                    comboBoxPrice.SelectedIndex = 0;
                    comboBoxCity.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при заполнении фильтров: " + ex.Message);
            }
        }
        private void FilterData(object sender, EventArgs e)
        {
            try
            {
                // Начальный запрос, который выбирает все данные
                string filterQuery = "SELECT * FROM RealtyView WHERE 1=1";

                // Проверка, выбран ли хоть один фильтр
                bool isFilterApplied = false;

                // Фильтр по типу недвижимости
                if (comboBoxPropertyType.SelectedIndex > 0) // Индекс > 0 означает, что выбрано значение, отличное от "Все"
                {
                    filterQuery += " AND type_name = @type";
                    isFilterApplied = true;
                }

                // Фильтр по городу
                if (comboBoxCity.SelectedIndex > 0) // Индекс > 0 означает, что выбрано значение, отличное от "Все"
                {
                    filterQuery += " AND city_name = @city";
                    isFilterApplied = true;
                }

                // Фильтр по количеству комнат с использованием диапазона
                if (comboBoxRoomCount.SelectedIndex > 0)
                {
                    switch (comboBoxRoomCount.SelectedIndex)
                    {
                        case 1:
                            filterQuery += " AND quantity_rooms = 1";
                            break;
                        case 2:
                            filterQuery += " AND quantity_rooms BETWEEN 1 AND 3";
                            break;
                        case 3:
                            filterQuery += " AND quantity_rooms BETWEEN 4 AND 5";
                            break;
                        case 4:
                            filterQuery += " AND quantity_rooms > 5";
                            break;
                    }
                    isFilterApplied = true;
                }

                // Фильтр по цене с использованием диапазона
                if (comboBoxPrice.SelectedIndex > 0)
                {
                    switch (comboBoxPrice.SelectedIndex)
                    {
                        case 1:
                            filterQuery += " AND cost < 1000000";
                            break;
                        case 2:
                            filterQuery += " AND cost BETWEEN 1000000 AND 5000000";
                            break;
                        case 3:
                            filterQuery += " AND cost BETWEEN 5000000 AND 10000000";
                            break;
                        case 4:
                            filterQuery += " AND cost > 10000000";
                            break;
                    }
                    isFilterApplied = true;
                }

                // Фильтр по текстовому поиску
                if (!string.IsNullOrEmpty(SearchTb.Text))
                {
                    filterQuery += " AND (type_name LIKE @SearchText OR Description LIKE @SearchText)";
                    isFilterApplied = true;
                }

                // Если ни один фильтр не выбран, возвращаем исходное состояние, показывая все данные
                if (!isFilterApplied)
                {
                    filterQuery = "SELECT * FROM RealtyView";
                }

                using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionRealty))
                {
                    SqlCommand command = new SqlCommand(filterQuery, connection);

                    // Параметры для фильтров
                    if (comboBoxPropertyType.SelectedIndex > 0)
                    {
                        command.Parameters.AddWithValue("@type", comboBoxPropertyType.SelectedItem.ToString());
                    }
                    if (comboBoxCity.SelectedIndex > 0)
                    {
                        command.Parameters.AddWithValue("@city", comboBoxCity.SelectedItem.ToString());
                    }
                    if (!string.IsNullOrEmpty(SearchTb.Text))
                    {
                        command.Parameters.AddWithValue("@SearchText", "%" + SearchTb.Text + "%");
                    }
                    

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    dataGridViewRealty.DataSource = table;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при фильтрации данных: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            FormAuthorization fa = new FormAuthorization();
            fa.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AddRealtyForm addrealty = new AddRealtyForm(_userId);
            addrealty.ShowDialog();
        }

        private void добавитьВИзбранноеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridViewRealty.CurrentRow != null)
            {
                try
                {
                    // Получаем user_id и realty_id
                    int userId = _userId;

                    // Убедитесь, что имя столбца "realty_id" корректно!
                    int realtyId = Convert.ToInt32(dataGridViewRealty.CurrentRow.Cells[9].Value);

                    DateTime dateAdded = DateTime.Now;

                    // SQL-запрос с проверкой на существование дубликатов
                    string query = @"
                IF NOT EXISTS (SELECT 1 FROM FavoriteRealty WHERE user_id = @UserId AND realty_id = @RealtyId)
                BEGIN
                    INSERT INTO FavoriteRealty (user_id, realty_id, date_added) 
                    VALUES (@UserId, @RealtyId, @DateAdded)
                END";

                    // Локальное соединение
                    using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionRealty))
                    {
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@UserId", userId);
                            command.Parameters.AddWithValue("@RealtyId", realtyId);
                            command.Parameters.AddWithValue("@DateAdded", dateAdded);

                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();
                            connection.Close();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Недвижимость добавлена в избранное!");
                            }
                            else
                            {
                                MessageBox.Show("Эта недвижимость уже добавлена в избранное.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите объект недвижимости для добавления в избранное.");
            }
        }


        private void записатьсяНаПросмотрToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int selectedRealtyId = 0;

            // Проверяем, выбрана ли строка в DataGridView
            if (dataGridViewRealty.CurrentRow == null)
            {
                MessageBox.Show("Пожалуйста, выберите объект недвижимости.");
                return;
            }

            // Проверяем наличие столбца realty_id
            if (!dataGridViewRealty.Columns.Contains("realtyidDataGridViewTextBoxColumn"))
            {
                MessageBox.Show("Столбец с идентификатором объекта недвижимости отсутствует.");
                return;
            }

            // Получаем значение realty_id
            var cellValue = dataGridViewRealty.CurrentRow.Cells["realtyidDataGridViewTextBoxColumn"].Value;

            if (cellValue == null || cellValue == DBNull.Value)
            {
                MessageBox.Show("Не удалось получить идентификатор объекта недвижимости.");
                return;
            }

            selectedRealtyId = Convert.ToInt32(cellValue);

            int clientId = _userId; // ID клиента
            decimal realtyCost = 0;
            decimal transactionAmount = 0;
            int realtorId = 0;

            try
            {
                // Шаг 1: Получаем стоимость и ID риэлтора
                string query = @"
SELECT 
    r.cost,
    r.realtor_id
FROM [dbo].[Realty] r
WHERE r.realty_id = @realtyId";

                using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionRealty))
                {
                    SqlCommand cmd = new SqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@realtyId", selectedRealtyId);

                    connection.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            realtyCost = reader["cost"] != DBNull.Value ? Convert.ToDecimal(reader["cost"]) : 0;
                            realtorId = reader["realtor_id"] != DBNull.Value ? Convert.ToInt32(reader["realtor_id"]) : 0;
                        }
                        else
                        {
                            MessageBox.Show("Не удалось найти информацию о выбранном объекте.");
                            return;
                        }
                    }
                }

                if (realtorId == 0)
                {
                    MessageBox.Show("Не удалось определить риэлтора.");
                    return;
                }

                // Шаг 2: Рассчитываем transactionAmount как стоимость недвижимости + 4% комиссии
                transactionAmount = realtyCost + (realtyCost * 0.04m);

                // Шаг 3: Добавляем запись в таблицу Order со статусом 4 (Записан на просмотр)
                string insertOrderQuery = @"
INSERT INTO [dbo].[Order] (client_id, realtor_id, realty_id, status_order, order_date, transaction_amount)
VALUES (@clientId, @realtorId, @realtyId, @statusId, @orderDate, @transactionAmount)";

                using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionRealty))
                {
                    SqlCommand orderCommand = new SqlCommand(insertOrderQuery, connection);
                    orderCommand.Parameters.AddWithValue("@clientId", clientId);
                    orderCommand.Parameters.AddWithValue("@realtorId", realtorId);
                    orderCommand.Parameters.AddWithValue("@realtyId", selectedRealtyId);
                    orderCommand.Parameters.AddWithValue("@statusId", 4); // Статус "Записан на просмотр"
                    orderCommand.Parameters.AddWithValue("@orderDate", DateTime.Now);
                    orderCommand.Parameters.AddWithValue("@transactionAmount", transactionAmount);

                    connection.Open();
                    orderCommand.ExecuteNonQuery();
                    MessageBox.Show($"Вы успешно записались на просмотр.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void ViewOrderHistory()
        {
            int clientId = _userId;  // Получаем ID текущего клиента

            try
            {
                using (SqlConnection conn = new SqlConnection(Properties.Settings.Default.connectionRealty))
                {
                    string query = @"
SELECT 
    t.type_name AS [Тип недвижимости], 
    c.city_name AS [Город],  
    r.address AS [Улица],  
    o.order_date AS [Дата изменения]
FROM [dbo].[Order] o
JOIN [dbo].[Realty] r ON o.realty_id = r.realty_id
JOIN [dbo].[RealtyType] t ON r.type_id = t.type_id
JOIN [dbo].[city] c ON r.city_id = c.city_id  
WHERE o.client_id = @clientId AND o.status_order = 4";   // Статус "На просмотре"

                    SqlCommand command = new SqlCommand(query, conn);
                    command.Parameters.AddWithValue("@clientId", clientId);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    if (dataTable.Rows.Count == 0)
                    {
                        MessageBox.Show("История просмотров пуста.");
                    }

                    // Выводим историю в DataGridView
                    dataGridViewHistory.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void LoadFavorites()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionRealty))
                {
                    // Новый запрос для получения нужных данных
                    string query = @"
            SELECT 
                f.favorite_id AS [Номер избранного],
                r.description AS [Описание недвижимости],
                f.date_added AS [Дата добавления]
            FROM FavoriteRealty f
            JOIN Realty r ON f.realty_id = r.realty_id
            WHERE f.user_id = @UserId;";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@UserId", _userId);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    dataGridViewFavorites.DataSource = table;

                    // Настройка авторазмера столбцов
                    foreach (DataGridViewColumn column in dataGridViewFavorites.Columns)
                    {
                        column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке избранного: " + ex.Message);
            }
        }

        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridViewFavorites.CurrentRow != null)
            {
                try
                {
                    // Получаем номер избранного из текущей строки DataGridViewFavorites
                    int favoriteId = Convert.ToInt32(dataGridViewFavorites.CurrentRow.Cells["Номер избранного"].Value);

                    // SQL-запрос для удаления записи
                    string deleteQuery = "DELETE FROM FavoriteRealty WHERE favorite_id = @FavoriteId";

                    using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionRealty))
                    {
                        SqlCommand command = new SqlCommand(deleteQuery, connection);
                        command.Parameters.AddWithValue("@FavoriteId", favoriteId);

                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        connection.Close();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Объект удален из избранного.");
                        }
                        else
                        {
                            MessageBox.Show("Ошибка: запись не найдена.");
                        }

                        // Обновляем DataGridViewFavorites
                        LoadFavorites();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка удаления: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись для удаления.");
            }
        }

        private bool BuyRealty(int realtyId)
        {
            try
            {
                using (var connection = new SqlConnection(Properties.Settings.Default.connectionRealty))
                {
                    connection.Open();

                    // Начало транзакции для обеспечения согласованности данных
                    using (var transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Шаг 1: Обновление статуса недвижимости
                            string updateRealtyQuery = @"
                        UPDATE [EstateAgency].[dbo].[Realty] 
                        SET status_id = 2 -- 2 - статус 'Продано'
                        WHERE realty_id = @realty_id AND status_id != 2";

                            using (var updateCommand = new SqlCommand(updateRealtyQuery, connection, transaction))
                            {
                                updateCommand.Parameters.AddWithValue("@realty_id", realtyId);
                                int rowsAffected = updateCommand.ExecuteNonQuery();

                                if (rowsAffected == 0)
                                {
                                    // Если ни одна запись не обновлена, недвижимость уже продана
                                    transaction.Rollback();
                                    return false;
                                }
                            }

                            // Шаг 2: Вставка данных о сделке в таблицу Order
                            string insertOrderQuery = @"
                        INSERT INTO [EstateAgency].[dbo].[Order] 
                        (order_date, transaction_amount, status_order, client_id, realtor_id, realty_id) 
                        VALUES 
                        (@order_date, @transaction_amount, @status_order, @client_id, @realtor_id, @realty_id)";

                            using (var insertCommand = new SqlCommand(insertOrderQuery, connection, transaction))
                            {
                                // Получение данных клиента и риелтора из других источников
                                int clientId = _userId; // Метод получения ID текущего клиента
                                int realtorId = GetRealtorIdByRealty(realtyId, connection, transaction); // Метод получения ID риелтора
                                decimal transactionAmount = GetRealtyCost(realtyId, connection, transaction); // Метод получения стоимости недвижимости

                                // Добавляем параметры
                                insertCommand.Parameters.AddWithValue("@order_date", DateTime.Now);
                                insertCommand.Parameters.AddWithValue("@transaction_amount", transactionAmount);
                                insertCommand.Parameters.AddWithValue("@status_order", 2);
                                insertCommand.Parameters.AddWithValue("@client_id", clientId);
                                insertCommand.Parameters.AddWithValue("@realtor_id", realtorId);
                                insertCommand.Parameters.AddWithValue("@realty_id", realtyId);

                                insertCommand.ExecuteNonQuery();
                            }

                            // Подтверждение транзакции
                            transaction.Commit();
                            return true;
                        }
                        catch
                        {
                            // Откат транзакции при ошибке
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при выполнении операции: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private int GetRealtorIdByRealty(int realtyId, SqlConnection connection, SqlTransaction transaction)
        {
            string query = "SELECT realtor_id FROM [EstateAgency].[dbo].[Realty] WHERE realty_id = @realty_id";
            using (var command = new SqlCommand(query, connection, transaction))
            {
                command.Parameters.AddWithValue("@realty_id", realtyId);
                return Convert.ToInt32(command.ExecuteScalar());
            }
        }

        private decimal GetRealtyCost(int realtyId, SqlConnection connection, SqlTransaction transaction)
        {
            string query = "SELECT cost FROM [EstateAgency].[dbo].[Realty] WHERE realty_id = @realty_id";
            using (var command = new SqlCommand(query, connection, transaction))
            {
                command.Parameters.AddWithValue("@realty_id", realtyId);
                return Convert.ToDecimal(command.ExecuteScalar());
            }
        }

        private void купитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Проверяем, выделена ли строка
            if (dataGridViewRealty.SelectedRows.Count > 0)
            {
                var selectedRow = dataGridViewRealty.SelectedRows[0];

                // Получаем идентификатор недвижимости
                int realtyId = Convert.ToInt32(selectedRow.Cells["realtyidDataGridViewTextBoxColumn"].Value);

                // Проверяем текущий статус недвижимости
                string status = selectedRow.Cells["statusnameDataGridViewTextBoxColumn"].Value.ToString();

                if (status == "Продано")
                {
                    MessageBox.Show("Эта недвижимость уже продана.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Получаем сумму сделки
                decimal transactionAmount = Convert.ToDecimal(selectedRow.Cells["costDataGridViewTextBoxColumn"].Value); // Предположим, колонка с ценой называется "costDataGridViewTextBoxColumn"

                // Подтверждение покупки с выводом суммы
                DialogResult result = MessageBox.Show(
                    $"Вы уверены, что хотите купить эту недвижимость за {transactionAmount:C}?", // Форматируем как валюту
                    "Подтверждение покупки",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    // Попытка купить недвижимость
                    if (BuyRealty(realtyId))
                    {
                        // Если успешно, обновляем статус в DataGridView
                        selectedRow.Cells["statusnameDataGridViewTextBoxColumn"].Value = "Продано";

                        MessageBox.Show($"Поздравляем с покупкой недвижимости за {transactionAmount:C}!", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        // Сообщение в случае ошибки
                        MessageBox.Show("Не удалось купить недвижимость. Повторите попытку позже.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                // Сообщение, если ничего не выбрано
                MessageBox.Show("Пожалуйста, выберите недвижимость для покупки.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void LoadRealtyData()
        {
            using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionRealty))
            {
                try
                {
                    connection.Open();

                    // SQL-запрос для получения данных
                    string query = @"SELECT r.address, r.cost, r.description, r.quantity_rooms, r.square, r.year_founded, 
                            st.status_name, rt.type_name, c.city_name, r.realty_id, r.photo
                            FROM dbo.Realty AS r
                            INNER JOIN dbo.StatusType AS st ON r.status_id = st.status_id
                            INNER JOIN dbo.RealtyType AS rt ON r.type_id = rt.type_id
                            INNER JOIN dbo.City AS c ON r.city_id = c.city_id";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Привязка данных к DataGridView
                    dataGridViewRealty.DataSource = dataTable;

                    // Добавляем колонку для фото, если ее еще нет
                    if (!dataGridViewRealty.Columns.Contains("photo"))
                    {
                        DataGridViewImageColumn photoColumn = new DataGridViewImageColumn
                        {
                            Name = "photo",
                            HeaderText = "Фото",
                            ImageLayout = DataGridViewImageCellLayout.Zoom
                        };
                        dataGridViewRealty.Columns.Add(photoColumn);
                    }

                    // Устанавливаем изображения или заглушку
                    foreach (DataGridViewRow row in dataGridViewRealty.Rows)
                    {
                        if (row.DataBoundItem is DataRowView dataRowView)
                        {
                            byte[] imageData = dataRowView["photo"] as byte[];

                            if (imageData != null && imageData.Length > 0)
                            {
                                using (MemoryStream ms = new MemoryStream(imageData))
                                {
                                    row.Cells["photo"].Value = Image.FromStream(ms);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при загрузке данных: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dataGridViewRealty_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Получение ID недвижимости из выбранной строки
                DataGridViewRow row = dataGridViewRealty.Rows[e.RowIndex];
                int realtyId = Convert.ToInt32(row.Cells["realty_id"].Value);

                // Загрузка изображения для выбранной недвижимости
                LoadRealtyData();
            }
        }
    }
}

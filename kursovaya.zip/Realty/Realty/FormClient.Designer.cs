﻿namespace Realty
{
    partial class FormClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormClient));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGridViewHistory = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.удалитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridViewFavorites = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PatronymicTb = new System.Windows.Forms.TextBox();
            this.EmailTb = new System.Windows.Forms.TextBox();
            this.NameTb = new System.Windows.Forms.TextBox();
            this.PhoneTb = new System.Windows.Forms.TextBox();
            this.SurnameTb = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.dataGridViewRealty = new System.Windows.Forms.DataGridView();
            this.citynameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typenameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityroomsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.squareDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearfoundedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.realtyidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.photo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.realtyViewBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.estateAgencyDataSet13 = new Realty.EstateAgencyDataSet13();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBoxCity = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SearchTb = new System.Windows.Forms.TextBox();
            this.comboBoxRoomCount = new System.Windows.Forms.ComboBox();
            this.comboBoxPrice = new System.Windows.Forms.ComboBox();
            this.comboBoxPropertyType = new System.Windows.Forms.ComboBox();
            this.realtyViewBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.estateAgencyDataSet10 = new Realty.EstateAgencyDataSet10();
            this.realtyViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.estateAgencyDataSet1 = new Realty.EstateAgencyDataSet1();
            this.realtyViewBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.estateAgencyDataSet6 = new Realty.EstateAgencyDataSet6();
            this.realtyViewBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.estateAgencyDataSet3 = new Realty.EstateAgencyDataSet3();
            this.realtyViewBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.estateAgencyDataSet2 = new Realty.EstateAgencyDataSet2();
            this.estateAgencyDataSet = new Realty.EstateAgencyDataSet();
            this.estateAgencyDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.realtyViewTableAdapter = new Realty.EstateAgencyDataSet1TableAdapters.RealtyViewTableAdapter();
            this.realtyViewTableAdapter1 = new Realty.EstateAgencyDataSet2TableAdapters.RealtyViewTableAdapter();
            this.realtyViewTableAdapter2 = new Realty.EstateAgencyDataSet3TableAdapters.RealtyViewTableAdapter();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.добавитьВИзбранноеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.записатьсяНаПросмотрToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.купитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estateAgencyDataSet5 = new Realty.EstateAgencyDataSet5();
            this.realtyViewTableAdapter3 = new Realty.EstateAgencyDataSet6TableAdapters.RealtyViewTableAdapter();
            this.estateAgencyDataSet5BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.realtyViewTableAdapter4 = new Realty.EstateAgencyDataSet10TableAdapters.RealtyViewTableAdapter();
            this.realtyViewTableAdapter5 = new Realty.EstateAgencyDataSet13TableAdapters.RealtyViewTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHistory)).BeginInit();
            this.contextMenuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFavorites)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRealty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.realtyViewBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet13)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.realtyViewBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.realtyViewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.realtyViewBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.realtyViewBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.realtyViewBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSetBindingSource)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet5BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControl1.Location = new System.Drawing.Point(1, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1009, 727);
            this.tabControl1.TabIndex = 8;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1001, 698);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Личный кабинет";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.SlateGray;
            this.button2.Font = new System.Drawing.Font("Bookman Old Style", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(24, 636);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(120, 55);
            this.button2.TabIndex = 15;
            this.button2.Text = "Продать";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataGridViewHistory);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.dataGridViewFavorites);
            this.groupBox2.Location = new System.Drawing.Point(430, 110);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(561, 493);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Информация по записям";
            // 
            // dataGridViewHistory
            // 
            this.dataGridViewHistory.AllowUserToAddRows = false;
            this.dataGridViewHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHistory.ContextMenuStrip = this.contextMenuStrip2;
            this.dataGridViewHistory.Location = new System.Drawing.Point(9, 49);
            this.dataGridViewHistory.Name = "dataGridViewHistory";
            this.dataGridViewHistory.Size = new System.Drawing.Size(546, 183);
            this.dataGridViewHistory.TabIndex = 11;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.удалитьToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(119, 26);
            //this.contextMenuStrip2.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip2_Opening);
            // 
            // удалитьToolStripMenuItem
            // 
            this.удалитьToolStripMenuItem.Name = "удалитьToolStripMenuItem";
            this.удалитьToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.удалитьToolStripMenuItem.Text = "Удалить";
            this.удалитьToolStripMenuItem.Click += new System.EventHandler(this.удалитьToolStripMenuItem_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(219, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(145, 20);
            this.label7.TabIndex = 12;
            this.label7.Text = "История записей";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(240, 271);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "Избранное";
            //this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // dataGridViewFavorites
            // 
            this.dataGridViewFavorites.AllowUserToAddRows = false;
            this.dataGridViewFavorites.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFavorites.ContextMenuStrip = this.contextMenuStrip2;
            this.dataGridViewFavorites.Location = new System.Drawing.Point(6, 294);
            this.dataGridViewFavorites.Name = "dataGridViewFavorites";
            this.dataGridViewFavorites.Size = new System.Drawing.Size(549, 183);
            this.dataGridViewFavorites.TabIndex = 7;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.PatronymicTb);
            this.groupBox1.Controls.Add(this.EmailTb);
            this.groupBox1.Controls.Add(this.NameTb);
            this.groupBox1.Controls.Add(this.PhoneTb);
            this.groupBox1.Controls.Add(this.SurnameTb);
            this.groupBox1.Location = new System.Drawing.Point(24, 110);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(391, 370);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Личная информация";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(41, 26);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(176, 163);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // PatronymicTb
            // 
            this.PatronymicTb.Location = new System.Drawing.Point(41, 266);
            this.PatronymicTb.Name = "PatronymicTb";
            this.PatronymicTb.Size = new System.Drawing.Size(176, 22);
            this.PatronymicTb.TabIndex = 3;
            // 
            // EmailTb
            // 
            this.EmailTb.Location = new System.Drawing.Point(41, 294);
            this.EmailTb.Name = "EmailTb";
            this.EmailTb.Size = new System.Drawing.Size(176, 22);
            this.EmailTb.TabIndex = 4;
            // 
            // NameTb
            // 
            this.NameTb.Location = new System.Drawing.Point(41, 238);
            this.NameTb.Name = "NameTb";
            this.NameTb.Size = new System.Drawing.Size(176, 22);
            this.NameTb.TabIndex = 2;
            // 
            // PhoneTb
            // 
            this.PhoneTb.Location = new System.Drawing.Point(41, 322);
            this.PhoneTb.Name = "PhoneTb";
            this.PhoneTb.Size = new System.Drawing.Size(176, 22);
            this.PhoneTb.TabIndex = 5;
            // 
            // SurnameTb
            // 
            this.SurnameTb.Location = new System.Drawing.Point(41, 210);
            this.SurnameTb.Name = "SurnameTb";
            this.SurnameTb.Size = new System.Drawing.Size(176, 22);
            this.SurnameTb.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SlateGray;
            this.button1.Font = new System.Drawing.Font("Bookman Old Style", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(871, 637);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 55);
            this.button1.TabIndex = 9;
            this.button1.Text = "Выход";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SlateGray;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-4, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1010, 73);
            this.panel1.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(361, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(311, 38);
            this.label1.TabIndex = 1;
            this.label1.Text = "Личный кабинет";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.richTextBox1);
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Controls.Add(this.dataGridViewRealty);
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1001, 698);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Недвижимость";
            this.tabPage2.UseVisualStyleBackColor = true;
            //this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.textBox4);
            this.groupBox3.Controls.Add(this.textBox1);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.textBox2);
            this.groupBox3.Controls.Add(this.textBox3);
            this.groupBox3.Font = new System.Drawing.Font("Bookman Old Style", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox3.Location = new System.Drawing.Point(593, 346);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(316, 168);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "О квартире";
            //this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(6, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 20);
            this.label6.TabIndex = 7;
            this.label6.Text = "Город";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(6, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(126, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Кол-во комнат";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(6, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Площадь";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox4.Location = new System.Drawing.Point(139, 126);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(165, 26);
            this.textBox4.TabIndex = 12;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(139, 29);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(165, 26);
            this.textBox1.TabIndex = 8;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(8, 132);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 20);
            this.label12.TabIndex = 11;
            this.label12.Text = "Цена";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox2.Location = new System.Drawing.Point(139, 93);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(165, 26);
            this.textBox2.TabIndex = 9;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox3.Location = new System.Drawing.Point(139, 61);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(165, 26);
            this.textBox3.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(3, 507);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Описание";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox1.Location = new System.Drawing.Point(7, 530);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(387, 137);
            this.richTextBox1.TabIndex = 3;
            this.richTextBox1.Text = "";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Realty.Properties.Resources.house1;
            this.pictureBox2.Location = new System.Drawing.Point(11, 308);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(207, 196);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // dataGridViewRealty
            // 
            this.dataGridViewRealty.AllowUserToAddRows = false;
            this.dataGridViewRealty.AllowUserToDeleteRows = false;
            this.dataGridViewRealty.AutoGenerateColumns = false;
            this.dataGridViewRealty.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewRealty.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.citynameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.typenameDataGridViewTextBoxColumn,
            this.costDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn,
            this.quantityroomsDataGridViewTextBoxColumn,
            this.squareDataGridViewTextBoxColumn,
            this.yearfoundedDataGridViewTextBoxColumn,
            this.statusnameDataGridViewTextBoxColumn,
            this.realtyidDataGridViewTextBoxColumn,
            this.photo});
            this.dataGridViewRealty.DataSource = this.realtyViewBindingSource5;
            this.dataGridViewRealty.Location = new System.Drawing.Point(6, 86);
            this.dataGridViewRealty.Name = "dataGridViewRealty";
            this.dataGridViewRealty.ReadOnly = true;
            this.dataGridViewRealty.Size = new System.Drawing.Size(992, 216);
            this.dataGridViewRealty.TabIndex = 1;
            this.dataGridViewRealty.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            //this.dataGridViewRealty.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // citynameDataGridViewTextBoxColumn
            // 
            this.citynameDataGridViewTextBoxColumn.DataPropertyName = "city_name";
            this.citynameDataGridViewTextBoxColumn.HeaderText = "Город";
            this.citynameDataGridViewTextBoxColumn.Name = "citynameDataGridViewTextBoxColumn";
            this.citynameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Адрес";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            this.addressDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // typenameDataGridViewTextBoxColumn
            // 
            this.typenameDataGridViewTextBoxColumn.DataPropertyName = "type_name";
            this.typenameDataGridViewTextBoxColumn.HeaderText = "Тип недвижимости";
            this.typenameDataGridViewTextBoxColumn.Name = "typenameDataGridViewTextBoxColumn";
            this.typenameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // costDataGridViewTextBoxColumn
            // 
            this.costDataGridViewTextBoxColumn.DataPropertyName = "cost";
            this.costDataGridViewTextBoxColumn.HeaderText = "Площадь";
            this.costDataGridViewTextBoxColumn.Name = "costDataGridViewTextBoxColumn";
            this.costDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "Описание";
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            this.descriptionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // quantityroomsDataGridViewTextBoxColumn
            // 
            this.quantityroomsDataGridViewTextBoxColumn.DataPropertyName = "quantity_rooms";
            this.quantityroomsDataGridViewTextBoxColumn.HeaderText = "Количество комнат";
            this.quantityroomsDataGridViewTextBoxColumn.Name = "quantityroomsDataGridViewTextBoxColumn";
            this.quantityroomsDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // squareDataGridViewTextBoxColumn
            // 
            this.squareDataGridViewTextBoxColumn.DataPropertyName = "square";
            this.squareDataGridViewTextBoxColumn.HeaderText = "Площадь";
            this.squareDataGridViewTextBoxColumn.Name = "squareDataGridViewTextBoxColumn";
            this.squareDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // yearfoundedDataGridViewTextBoxColumn
            // 
            this.yearfoundedDataGridViewTextBoxColumn.DataPropertyName = "year_founded";
            this.yearfoundedDataGridViewTextBoxColumn.HeaderText = "Год постройки";
            this.yearfoundedDataGridViewTextBoxColumn.Name = "yearfoundedDataGridViewTextBoxColumn";
            this.yearfoundedDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // statusnameDataGridViewTextBoxColumn
            // 
            this.statusnameDataGridViewTextBoxColumn.DataPropertyName = "status_name";
            this.statusnameDataGridViewTextBoxColumn.HeaderText = "Статус";
            this.statusnameDataGridViewTextBoxColumn.Name = "statusnameDataGridViewTextBoxColumn";
            this.statusnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // realtyidDataGridViewTextBoxColumn
            // 
            this.realtyidDataGridViewTextBoxColumn.DataPropertyName = "realty_id";
            this.realtyidDataGridViewTextBoxColumn.HeaderText = "realty_id";
            this.realtyidDataGridViewTextBoxColumn.Name = "realtyidDataGridViewTextBoxColumn";
            this.realtyidDataGridViewTextBoxColumn.ReadOnly = true;
            this.realtyidDataGridViewTextBoxColumn.Visible = false;
            // 
            // photo
            // 
            this.photo.DataPropertyName = "photo";
            this.photo.HeaderText = "photo";
            this.photo.Name = "photo";
            this.photo.ReadOnly = true;
            this.photo.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.photo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.photo.Visible = false;
            // 
            // realtyViewBindingSource5
            // 
            this.realtyViewBindingSource5.DataMember = "RealtyView";
            this.realtyViewBindingSource5.DataSource = this.estateAgencyDataSet13;
            // 
            // estateAgencyDataSet13
            // 
            this.estateAgencyDataSet13.DataSetName = "EstateAgencyDataSet13";
            this.estateAgencyDataSet13.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SlateGray;
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.comboBoxCity);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.SearchTb);
            this.panel2.Controls.Add(this.comboBoxRoomCount);
            this.panel2.Controls.Add(this.comboBoxPrice);
            this.panel2.Controls.Add(this.comboBoxPropertyType);
            this.panel2.Location = new System.Drawing.Point(-4, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1009, 72);
            this.panel2.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(479, 6);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(45, 18);
            this.label14.TabIndex = 9;
            this.label14.Text = "Город";
            // 
            // comboBoxCity
            // 
            this.comboBoxCity.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxCity.FormattingEnabled = true;
            this.comboBoxCity.Location = new System.Drawing.Point(482, 29);
            this.comboBoxCity.Name = "comboBoxCity";
            this.comboBoxCity.Size = new System.Drawing.Size(121, 28);
            this.comboBoxCity.TabIndex = 8;
            //this.comboBoxCity.SelectedIndexChanged += new System.EventHandler(this.comboBoxCity_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(860, 6);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(104, 18);
            this.label11.TabIndex = 7;
            this.label11.Text = "Кол-во комнат";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(733, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 18);
            this.label10.TabIndex = 6;
            this.label10.Text = "Цена";
            //this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(606, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(33, 18);
            this.label9.TabIndex = 5;
            this.label9.Text = "Тип";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(12, 6);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 18);
            this.label8.TabIndex = 4;
            this.label8.Text = "Поиск";
            // 
            // SearchTb
            // 
            this.SearchTb.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SearchTb.Location = new System.Drawing.Point(14, 31);
            this.SearchTb.Name = "SearchTb";
            this.SearchTb.Size = new System.Drawing.Size(157, 26);
            this.SearchTb.TabIndex = 0;
            //this.SearchTb.TextChanged += new System.EventHandler(this.textBoxSearch_TextChanged);
            // 
            // comboBoxRoomCount
            // 
            this.comboBoxRoomCount.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxRoomCount.FormattingEnabled = true;
            this.comboBoxRoomCount.Location = new System.Drawing.Point(863, 29);
            this.comboBoxRoomCount.Name = "comboBoxRoomCount";
            this.comboBoxRoomCount.Size = new System.Drawing.Size(121, 28);
            this.comboBoxRoomCount.TabIndex = 3;
            // 
            // comboBoxPrice
            // 
            this.comboBoxPrice.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxPrice.FormattingEnabled = true;
            this.comboBoxPrice.Location = new System.Drawing.Point(736, 29);
            this.comboBoxPrice.Name = "comboBoxPrice";
            this.comboBoxPrice.Size = new System.Drawing.Size(121, 28);
            this.comboBoxPrice.TabIndex = 2;
            // 
            // comboBoxPropertyType
            // 
            this.comboBoxPropertyType.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxPropertyType.FormattingEnabled = true;
            this.comboBoxPropertyType.Location = new System.Drawing.Point(609, 29);
            this.comboBoxPropertyType.Name = "comboBoxPropertyType";
            this.comboBoxPropertyType.Size = new System.Drawing.Size(121, 28);
            this.comboBoxPropertyType.TabIndex = 1;
            // 
            // realtyViewBindingSource4
            // 
            this.realtyViewBindingSource4.DataMember = "RealtyView";
            this.realtyViewBindingSource4.DataSource = this.estateAgencyDataSet10;
            // 
            // estateAgencyDataSet10
            // 
            this.estateAgencyDataSet10.DataSetName = "EstateAgencyDataSet10";
            this.estateAgencyDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // realtyViewBindingSource
            // 
            this.realtyViewBindingSource.DataMember = "RealtyView";
            this.realtyViewBindingSource.DataSource = this.estateAgencyDataSet1;
            // 
            // estateAgencyDataSet1
            // 
            this.estateAgencyDataSet1.DataSetName = "EstateAgencyDataSet1";
            this.estateAgencyDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // realtyViewBindingSource3
            // 
            this.realtyViewBindingSource3.DataMember = "RealtyView";
            this.realtyViewBindingSource3.DataSource = this.estateAgencyDataSet6;
            // 
            // estateAgencyDataSet6
            // 
            this.estateAgencyDataSet6.DataSetName = "EstateAgencyDataSet6";
            this.estateAgencyDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // realtyViewBindingSource2
            // 
            this.realtyViewBindingSource2.DataMember = "RealtyView";
            this.realtyViewBindingSource2.DataSource = this.estateAgencyDataSet3;
            // 
            // estateAgencyDataSet3
            // 
            this.estateAgencyDataSet3.DataSetName = "EstateAgencyDataSet3";
            this.estateAgencyDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // realtyViewBindingSource1
            // 
            this.realtyViewBindingSource1.DataMember = "RealtyView";
            this.realtyViewBindingSource1.DataSource = this.estateAgencyDataSet2;
            // 
            // estateAgencyDataSet2
            // 
            this.estateAgencyDataSet2.DataSetName = "EstateAgencyDataSet2";
            this.estateAgencyDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // estateAgencyDataSet
            // 
            this.estateAgencyDataSet.DataSetName = "EstateAgencyDataSet";
            this.estateAgencyDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // estateAgencyDataSetBindingSource
            // 
            this.estateAgencyDataSetBindingSource.DataSource = this.estateAgencyDataSet;
            this.estateAgencyDataSetBindingSource.Position = 0;
            // 
            // realtyViewTableAdapter
            // 
            this.realtyViewTableAdapter.ClearBeforeFill = true;
            // 
            // realtyViewTableAdapter1
            // 
            this.realtyViewTableAdapter1.ClearBeforeFill = true;
            // 
            // realtyViewTableAdapter2
            // 
            this.realtyViewTableAdapter2.ClearBeforeFill = true;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьВИзбранноеToolStripMenuItem,
            this.записатьсяНаПросмотрToolStripMenuItem,
            this.купитьToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(211, 70);
            // 
            // добавитьВИзбранноеToolStripMenuItem
            // 
            this.добавитьВИзбранноеToolStripMenuItem.Name = "добавитьВИзбранноеToolStripMenuItem";
            this.добавитьВИзбранноеToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.добавитьВИзбранноеToolStripMenuItem.Text = "Добавить в избранное";
            this.добавитьВИзбранноеToolStripMenuItem.Click += new System.EventHandler(this.добавитьВИзбранноеToolStripMenuItem_Click);
            // 
            // записатьсяНаПросмотрToolStripMenuItem
            // 
            this.записатьсяНаПросмотрToolStripMenuItem.Name = "записатьсяНаПросмотрToolStripMenuItem";
            this.записатьсяНаПросмотрToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.записатьсяНаПросмотрToolStripMenuItem.Text = "Записаться на просмотр";
            this.записатьсяНаПросмотрToolStripMenuItem.Click += new System.EventHandler(this.записатьсяНаПросмотрToolStripMenuItem_Click);
            // 
            // купитьToolStripMenuItem
            // 
            this.купитьToolStripMenuItem.Name = "купитьToolStripMenuItem";
            this.купитьToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.купитьToolStripMenuItem.Text = "Купить";
            this.купитьToolStripMenuItem.Click += new System.EventHandler(this.купитьToolStripMenuItem_Click);
            // 
            // estateAgencyDataSet5
            // 
            this.estateAgencyDataSet5.DataSetName = "EstateAgencyDataSet5";
            this.estateAgencyDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // realtyViewTableAdapter3
            // 
            this.realtyViewTableAdapter3.ClearBeforeFill = true;
            // 
            // estateAgencyDataSet5BindingSource
            // 
            this.estateAgencyDataSet5BindingSource.DataSource = this.estateAgencyDataSet5;
            this.estateAgencyDataSet5BindingSource.Position = 0;
            // 
            // realtyViewTableAdapter4
            // 
            this.realtyViewTableAdapter4.ClearBeforeFill = true;
            // 
            // realtyViewTableAdapter5
            // 
            this.realtyViewTableAdapter5.ClearBeforeFill = true;
            // 
            // FormClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1008, 729);
            this.Controls.Add(this.tabControl1);
            this.Name = "FormClient";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Купи-Продай";
            this.Load += new System.EventHandler(this.test_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHistory)).EndInit();
            this.contextMenuStrip2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFavorites)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRealty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.realtyViewBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet13)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.realtyViewBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.realtyViewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.realtyViewBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.realtyViewBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.realtyViewBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSetBindingSource)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.estateAgencyDataSet5BindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataGridViewHistory;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox PatronymicTb;
        private System.Windows.Forms.TextBox EmailTb;
        private System.Windows.Forms.TextBox NameTb;
        private System.Windows.Forms.TextBox PhoneTb;
        private System.Windows.Forms.TextBox SurnameTb;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridView dataGridViewRealty;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox SearchTb;
        private System.Windows.Forms.ComboBox comboBoxRoomCount;
        private System.Windows.Forms.ComboBox comboBoxPrice;
        private System.Windows.Forms.ComboBox comboBoxPropertyType;
        private EstateAgencyDataSet estateAgencyDataSet;
        private System.Windows.Forms.BindingSource estateAgencyDataSetBindingSource;
        private EstateAgencyDataSet1 estateAgencyDataSet1;
        private System.Windows.Forms.BindingSource realtyViewBindingSource;
        private EstateAgencyDataSet1TableAdapters.RealtyViewTableAdapter realtyViewTableAdapter;
        private System.Windows.Forms.DataGridView dataGridViewFavorites;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBoxCity;
        private EstateAgencyDataSet2 estateAgencyDataSet2;
        private System.Windows.Forms.BindingSource realtyViewBindingSource1;
        private EstateAgencyDataSet2TableAdapters.RealtyViewTableAdapter realtyViewTableAdapter1;
        private System.Windows.Forms.Button button2;
        private EstateAgencyDataSet3 estateAgencyDataSet3;
        private System.Windows.Forms.BindingSource realtyViewBindingSource2;
        private EstateAgencyDataSet3TableAdapters.RealtyViewTableAdapter realtyViewTableAdapter2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem добавитьВИзбранноеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem записатьсяНаПросмотрToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem купитьToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private EstateAgencyDataSet5 estateAgencyDataSet5;
        private EstateAgencyDataSet6 estateAgencyDataSet6;
        private System.Windows.Forms.BindingSource realtyViewBindingSource3;
        private EstateAgencyDataSet6TableAdapters.RealtyViewTableAdapter realtyViewTableAdapter3;
        private System.Windows.Forms.BindingSource estateAgencyDataSet5BindingSource;
        private EstateAgencyDataSet10 estateAgencyDataSet10;
        private System.Windows.Forms.BindingSource realtyViewBindingSource4;
        private EstateAgencyDataSet10TableAdapters.RealtyViewTableAdapter realtyViewTableAdapter4;
        private System.Windows.Forms.ToolStripMenuItem удалитьToolStripMenuItem;
        private EstateAgencyDataSet13 estateAgencyDataSet13;
        private System.Windows.Forms.BindingSource realtyViewBindingSource5;
        private EstateAgencyDataSet13TableAdapters.RealtyViewTableAdapter realtyViewTableAdapter5;
        private System.Windows.Forms.DataGridViewTextBoxColumn citynameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typenameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn costDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityroomsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn squareDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearfoundedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn realtyidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn photo;

        #endregion
        //private EstateAgencyDataSet estateAgencyDataSet;
        //private System.Windows.Forms.BindingSource realtyBindingSource;
        //private EstateAgencyDataSetTableAdapters.RealtyTableAdapter realtyTableAdapter;
    }
}
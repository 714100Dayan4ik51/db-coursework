﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Realty
{
    public partial class AddRealtyForm : Form
    {
        private int userId;
        private SqlConnection SqlConnect = new SqlConnection(Properties.Settings.Default.connectionRealty);
        public AddRealtyForm(int userId)
        {
            InitializeComponent();
            this.userId = userId;
        }

        private void AddRealtyForm_Load(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionRealty))
            {
                try
                {
                    connection.Open();

                    // Загрузка типов недвижимости
                    LoadComboBoxData(connection, comboBox1, "SELECT type_id, type_name FROM RealtyType", "type_name", "type_id");

                    // Загрузка городов
                    LoadComboBoxData(connection, comboBox2, "SELECT city_id, city_name FROM city", "city_name", "city_id");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при загрузке данных: " + ex.Message);
                }
            }
        }
        // Универсальный метод загрузки данных для ComboBox
        private void LoadComboBoxData(SqlConnection connection, ComboBox comboBox, string query, string displayMember, string valueMember)
        {
            using (SqlCommand cmd = new SqlCommand(query, connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
            {
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                comboBox.DataSource = dataTable;
                comboBox.DisplayMember = displayMember;
                comboBox.ValueMember = valueMember;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Проверка на заполненность всех обязательных полей
            if (string.IsNullOrWhiteSpace(comboBox1.Text) || // Тип недвижимости
                string.IsNullOrWhiteSpace(comboBox2.Text) || // Город
                string.IsNullOrWhiteSpace(textBox7.Text) || // Улица
                string.IsNullOrWhiteSpace(textBox1.Text) || // Цена
                string.IsNullOrWhiteSpace(textBox2.Text) || // Площадь
                string.IsNullOrWhiteSpace(textBox3.Text)) // Кол-во комнат
            {
                MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                return;
            }

            // Подключение к базе данных
            using (SqlConnection conn = new SqlConnection(Properties.Settings.Default.connectionRealty))
            {
                try
                {
                    conn.Open();

                    // SQL-запрос для вставки данных в таблицу Realty
                    string query = @"
INSERT INTO Realty (type_id, city_id, address, cost, square, quantity_rooms, description, year_founded, realtor_id)
VALUES (@type_id, @city_id, @address, @cost, @square, @quantity_rooms, @description, @year_founded, @realtor_id);
SELECT CAST(scope_identity() AS int);";  // Получаем ID только что добавленной записи

                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        // Добавление параметров из формы
                        command.Parameters.AddWithValue("@type_id", comboBox1.SelectedValue); // Тип недвижимости
                        command.Parameters.AddWithValue("@city_id", comboBox2.SelectedValue); // Город
                        command.Parameters.AddWithValue("@address", textBox7.Text); // Улица
                        command.Parameters.AddWithValue("@cost", textBox1.Text); // Цена
                        command.Parameters.AddWithValue("@square", textBox2.Text); // Площадь
                        command.Parameters.AddWithValue("@quantity_rooms", textBox3.Text); // Кол-во комнат
                        command.Parameters.AddWithValue("@description", string.IsNullOrWhiteSpace(textBox4.Text) ? (object)DBNull.Value : textBox4.Text); // Описание
                        command.Parameters.AddWithValue("@year_founded", string.IsNullOrWhiteSpace(textBox6.Text) ? (object)DBNull.Value : textBox6.Text); // Год постройки
                        command.Parameters.AddWithValue("@realtor_id", userId); // ID риелтора (человек, который выставляет недвижимость)

                        // Выполнение запроса и получение ID нового объекта
                        int newRealtyId = (int)command.ExecuteScalar();

                        // Если есть изображение, загружаем его в базу
                        if (pictureBox1.Image != null)
                        {
                            var uploader = new ImageUploader(Properties.Settings.Default.connectionRealty);
                            uploader.Upload(pictureBox1, newRealtyId);
                        }
                        MessageBox.Show("Данные успешно добавлены!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при добавлении данных: " + ex.Message);
                }
            }
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (var openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Image files(*.jpg, *.jpeg, *.png) | *.jpg; *.jpeg; *.png";
                openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.Image = Image.FromFile(openFileDialog.FileName);
                }
            }
        }

        class ImageUploader
        {
            private readonly string _connectionString;
            public ImageUploader(string connectionString)
            {
                _connectionString = connectionString;
            }

            public void Upload(PictureBox pictureBox, int realtyId)
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    // Конвертация изображения в байты
                    using (var memoryStream = new MemoryStream())
                    {
                        // Сохраняем изображение в память в формате JPEG
                        pictureBox.Image.Save(memoryStream, ImageFormat.Jpeg);
                        byte[] imageBytes = memoryStream.ToArray();

                        // SQL-запрос для вставки изображения в таблицу
                        using (var command = new SqlCommand("UPDATE Realty SET photo = @photo WHERE realty_id = @realty_id", connection))
                        {
                            command.Parameters.AddWithValue("@photo", imageBytes);
                            command.Parameters.AddWithValue("@realty_id", realtyId);  // Здесь realty_id — это ID объекта недвижимости

                            // Выполнение запроса
                            command.ExecuteNonQuery();
                        }
                    }
                }
            }
        }
    }
}


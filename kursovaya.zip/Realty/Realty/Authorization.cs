﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Realty
{
    public partial class FormAuthorization : Form
    {
        private SqlConnection SqlConnect = new SqlConnection(Properties.Settings.Default.connectionRealty);
        public FormAuthorization()
        {
            InitializeComponent();
        }

        string placeholderText = "Логин";
        string placeholderText1 = "Пароль";

        private void FormAuthorization_Load(object sender, EventArgs e)
        {
            PasswordTextBox.UseSystemPasswordChar = true;
            pictureBox3.Visible = false;

            LoginTextBox.Text = placeholderText;
            PasswordTextBox.Text = placeholderText1;

            LoginTextBox.Text = placeholderText;
            LoginTextBox.ForeColor = Color.Gray;  // Серый цвет для подсказки

            PasswordTextBox.Text = placeholderText1;
            PasswordTextBox.ForeColor = Color.Gray;  // Серый цвет для подсказки

            // Подключаем события для LoginTextBox
            LoginTextBox.Enter += LoginTextBox_Enter;
            LoginTextBox.Leave += LoginTextBox_Leave;

            // Подключаем события для PasswordTextBox
            PasswordTextBox.Enter += PasswordTextBox_Enter;
            PasswordTextBox.Leave += PasswordTextBox_Leave;

        }

        private void LoginTextBox_Enter(object sender, EventArgs e)
        {
            if (LoginTextBox.Text == placeholderText)
            {
                LoginTextBox.Text = "";
                LoginTextBox.ForeColor = Color.Black; // Обычный цвет текста
            }
        }
        private void LoginTextBox_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(LoginTextBox.Text))
            {
                LoginTextBox.Text = placeholderText;
                LoginTextBox.ForeColor = Color.Gray; // Цвет для placeholder
            }
        }

        private void PasswordTextBox_Enter(object sender, EventArgs e)
        {
            if (PasswordTextBox.Text == placeholderText1)
            {
                PasswordTextBox.Text = "";
                PasswordTextBox.ForeColor = Color.Black; // Обычный цвет текста
                PasswordTextBox.UseSystemPasswordChar = false; // Скрываем пароль при вводе
            }
        }

        private void PasswordTextBox_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(PasswordTextBox.Text))
            {
                PasswordTextBox.UseSystemPasswordChar = false; // Отключаем символы пароля для placeholder
                PasswordTextBox.Text = placeholderText1;
                PasswordTextBox.ForeColor = Color.Gray; // Цвет для placeholder
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LoginTextBox.Text = "";
            PasswordTextBox.Text = "";

            LoginTextBox.Text = placeholderText;
            LoginTextBox.ForeColor = Color.Gray; // Цвет для placeholder

            PasswordTextBox.Text = placeholderText1;
            PasswordTextBox.ForeColor = Color.Gray; // Цвет для placeholder
            PasswordTextBox.UseSystemPasswordChar = true; // Отключаем скрытие символов для placeholder
            pictureBox4.Visible = true;

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            PasswordTextBox.UseSystemPasswordChar = true;
            pictureBox3.Visible = true;
            pictureBox4.Visible = false;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            PasswordTextBox.UseSystemPasswordChar = false;
            pictureBox3.Visible = false;
            pictureBox4.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnect.Open();
                string query = "select * from [User] where login = @login and password = @password";
                using (SqlCommand command = new SqlCommand(query, SqlConnect))
                {
                    command.Parameters.AddWithValue("@login", LoginTextBox.Text);
                    command.Parameters.AddWithValue("@password", md5.hashPassword(PasswordTextBox.Text));

                    using (SqlDataReader sqlreader = command.ExecuteReader())
                    {
                        if (sqlreader.Read())
                        {
                            int numb = sqlreader.GetInt32(4);
                            int user_id = sqlreader.GetInt32(0);
                            this.Hide();

                            switch (numb)
                            {
                                case 1:
                                    sqlreader.Close();
                                    MessageBox.Show("Вы успешно вошли.");
                                    FormClient formClient = new FormClient(1, user_id);
                                    formClient.Show();
                                    break;

                                case 2:
                                    sqlreader.Close();
                                    MessageBox.Show("Вы успешно вошли.");
                                    Realtor formRealtor = new Realtor(2, user_id);
                                    formRealtor.Show();
                                    break;

                                case 3:
                                    sqlreader.Close();
                                    MessageBox.Show("Вы успешно вошли.");
                                    Admin formAdmin = new Admin(3);
                                    formAdmin.Show();
                                    break;

                               default:
                                   MessageBox.Show("Неизвестная роль пользователя!");
                                   break;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Неверный логин или пароль!");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (SqlConnect.State == ConnectionState.Open)
                    SqlConnect.Close();
            }
        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Registration registration = new Registration();
            registration.ShowDialog();
        }
    }
}
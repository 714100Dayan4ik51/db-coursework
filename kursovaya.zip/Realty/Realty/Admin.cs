﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Realty
{
    public partial class Admin : Form
    {
        int role;
        public Admin(int numb)
        {
            InitializeComponent();
            this.role = numb;

            dataGridView1.ContextMenuStrip = contextMenuStrip1;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.CellValueChanged += dataGridView1_CellValueChanged;
        }

        private void DeleteUser(int userId)
        {
            // Подключение к базе данных и выполнение команды удаления
            using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionRealty))
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand("DELETE FROM [User] WHERE user_id = @UserId", connection))
                {
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Пользователь удалён!");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            FormAuthorization authorization = new FormAuthorization();
            authorization.Show();
        }

        private void FormAdmin_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "estateAgencyDataSet.User". При необходимости она может быть перемещена или удалена.
            this.userTableAdapter.Fill(this.estateAgencyDataSet.User);
            dataGridView1.ReadOnly = false;
            dataGridView1.ReadOnly = false;
            dataGridView1.EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2;
            dataGridView1.Enabled = true;

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
            FormAuthorization formAuthorization = new FormAuthorization();
            formAuthorization.ShowDialog();
        }

        private void удалитьToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int userId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["user_id"].Value);

                var result = MessageBox.Show("Вы уверены, что хотите удалить эту запись?", "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    DeleteUser(userId);
                    this.userTableAdapter.Fill(this.estateAgencyDataSet.User);
                }
            }
            else
            {
                MessageBox.Show("Выберите запись для удаления.");
            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                int userId = Convert.ToInt32(row.Cells["user_id"].Value);
                string columnName = dataGridView1.Columns[e.ColumnIndex].DataPropertyName; // Используем DataPropertyName
                object newValue = row.Cells[e.ColumnIndex].Value;

                UpdateDatabase(userId, columnName, newValue);
            }
        }

        private void UpdateDatabase(int userId, string columnName, object newValue)
        {
            using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionRealty))
            {
                connection.Open();
                string query = $"UPDATE [User] SET {columnName} = @Value WHERE user_id = @UserId";

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Value", newValue ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@UserId", userId);

                    try
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Данные успешно обновлены.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка обновления: {ex.Message}");
                    }
                }
            }
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            string searchText = SearchTb.Text.ToLower();

            BindingSource bindingSource = dataGridView1.DataSource as BindingSource;
            if (bindingSource != null)
            {
                bindingSource.Filter = $"surname LIKE '%{searchText}%' OR " +
                                       $"name LIKE '%{searchText}%' OR " +
                                       $"patronymic LIKE '%{searchText}%' OR " +
                                       $"phone LIKE '%{searchText}%' OR " +
                                       $"login LIKE '%{searchText}%'";
            }
        }
    }
}

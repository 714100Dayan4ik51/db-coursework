﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Realty
{
    public partial class Realtor : Form
    {
        int role;
        private int userId;
        private int _userId;
        public Realtor(int numb, int userId)
        {
            InitializeComponent();
            this.role = numb;
            this._userId = userId;
        }

        private void FormRealtor_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "agencyTestDataSet6.RealtyView". При необходимости она может быть перемещена или удалена.
            this.realtyViewTableAdapter.Fill(this.estateAgencyDataSet4.RealtyView);

            dataGridView1.ContextMenuStrip = contextMenuStrip1;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            SearchTb.TextChanged += SearchTb_TextChanged;
            textBox4.TextChanged += textBox4_TextChanged;
            dataGridView2.DataSource = estateAgencyDataSet14.OrderView;
            dataGridView2.AutoGenerateColumns = true;


            foreach (DataGridViewColumn column in dataGridView2.Columns)
            {
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            FormAuthorization fa = new FormAuthorization();
            fa.ShowDialog();
        }

        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                try
                {
                    // Получаем ID записи из выбранной строки
                    int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["realty_id"].Value);

                    // Подтверждение удаления
                    var result = MessageBox.Show("Вы уверены, что хотите удалить запись?", "Подтверждение удаления", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionRealty))
                        {
                            connection.Open();
                            using (SqlCommand cmd = new SqlCommand("DELETE FROM Realty WHERE realty_id = @Id", connection))
                            {
                                cmd.Parameters.AddWithValue("@Id", id);
                                cmd.ExecuteNonQuery();
                            }
                        }

                        MessageBox.Show("Запись успешно удалена!");

                        // Обновляем данные в таблице после удаления
                        this.realtyViewTableAdapter.Fill(this.estateAgencyDataSet4.RealtyView);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при удалении: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Выберите строку для удаления.");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            richTextBox1.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            textBox1.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            textBox2.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
        }

        private void Realtor_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "estateAgencyDataSet17.OrderView". При необходимости она может быть перемещена или удалена.
            this.orderViewTableAdapter2.Fill(this.estateAgencyDataSet17.OrderView);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "estateAgencyDataSet16.OrderView". При необходимости она может быть перемещена или удалена.
            //this.orderViewTableAdapter2.Fill(this.estateAgencyDataSet16.OrderView);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "estateAgencyDataSet15.OrderView". При необходимости она может быть перемещена или удалена.
            this.orderViewTableAdapter1.Fill(this.estateAgencyDataSet15.OrderView);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "estateAgencyDataSet14.OrderView". При необходимости она может быть перемещена или удалена.
            this.orderViewTableAdapter.Fill(this.estateAgencyDataSet14.OrderView);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "estateAgencyDataSet4.RealtyView". При необходимости она может быть перемещена или удалена.
            this.realtyViewTableAdapter.Fill(this.estateAgencyDataSet4.RealtyView);
            // Загрузка данных в DataGridView
            this.realtyViewTableAdapter.Fill(this.estateAgencyDataSet4.RealtyView);
            LoadStatuses();
        }

        private void LoadStatuses()
        {
            string query = "SELECT status_id, status_name FROM dbo.StatusType"; // Запрос на выборку всех статусов

            using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionRealty))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                comboBox1.DisplayMember = "status_name"; // Отображаемое значение
                comboBox1.ValueMember = "status_id"; // Значение, которое отправляется при выборе
                comboBox1.DataSource = dataTable;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddRealtyForm addRealtyForm = new AddRealtyForm(_userId);
            addRealtyForm.ShowDialog();
            this.realtyViewTableAdapter.Fill(this.estateAgencyDataSet4.RealtyView);
        }

        private void SearchTb_TextChanged(object sender, EventArgs e)
        {
            FilterDataGridView1();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            FilterDataGridView2();
        }

        private void FilterDataGridView1()
        {
            string searchText = SearchTb.Text.Trim();

            try
            {
                using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionRealty))
                {
                    // SQL-запрос для поиска по городу, адресу, типу недвижимости, цене и площади
                    string query = @"SELECT * FROM RealtyView 
                             WHERE city_name LIKE @SearchText
                                OR address LIKE @SearchText
                                OR type_name LIKE @SearchText
                                OR cost LIKE @SearchText
                                OR square LIKE @SearchText";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable table = new DataTable();
                        adapter.Fill(table);

                        dataGridView1.DataSource = table;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при фильтрации первой таблицы: " + ex.Message);
            }
        }

        private void FilterDataGridView2()
        {
            string searchText = textBox4.Text.Trim();

            try
            {
                using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionRealty))
                {
                    // SQL-запрос для поиска по номеру заказа
                    string query = @"SELECT * FROM OrderView
                             WHERE order_id LIKE @SearchText";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable table = new DataTable();
                        adapter.Fill(table);

                        dataGridView2.DataSource = table;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при фильтрации второй таблицы: " + ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            richTextBox1.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            textBox1.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            textBox2.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            textBox3.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();

            string status = dataGridView1.CurrentRow.Cells["statusnameDataGridViewTextBoxColumn"].Value.ToString();
            comboBox1.SelectedItem = status; // Обновляем комбобокс

            object cellValue = dataGridView1.CurrentRow.Cells[8].Value;
            if (cellValue != null && !string.IsNullOrWhiteSpace(cellValue.ToString()))
            {
                string imagePath = Path.Combine(Application.StartupPath, "photos", cellValue.ToString());
                if (File.Exists(imagePath))
                {
                    pictureBox2.Image = Image.FromFile(imagePath);
                }
                else
                {
                    pictureBox2.Image = Image.FromFile(Path.Combine(Application.StartupPath, "photo", "house.png"));
                }
            }
        }

        private void UpdateOrderStatus(int realtyId, int newStatus)
        {
            string query = "UPDATE [dbo].[Realty] SET [status_id] = @status_id WHERE [realty_id] = @realty_id";

            using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connectionRealty))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@status_id", newStatus); // Обновляем статус
                command.Parameters.AddWithValue("@realty_id", realtyId); // ID недвижимости

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        //MessageBox.Show("Статус недвижимости успешно обновлен.");
                    }
                    else
                    {
                        MessageBox.Show("Недвижимость с указанным ID не найдена.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при обновлении статуса: " + ex.Message);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Проверяем, введен ли ID заказа
            if (string.IsNullOrWhiteSpace(textBox4.Text))
            {
                MessageBox.Show("Введите ID заказа.");
                return;
            }

            // Проверяем, выбран ли статус
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Выберите статус.");
                return;
            }

            try
            {
                // Получаем ID заказа
                int orderId = int.Parse(textBox4.Text); // Преобразование из строки в число

                // Получаем выбранный статус
                int newStatus = (int)comboBox1.SelectedValue;

                // Вызываем метод обновления статуса
                UpdateOrderStatus(orderId, newStatus);

                this.realtyViewTableAdapter.Fill(this.estateAgencyDataSet4.RealtyView);

                MessageBox.Show("Статус успешно обновлен!");
            }
            catch (FormatException)
            {
                MessageBox.Show("ID заказа должен быть числом.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox5.Text = dataGridView2.CurrentRow.Cells["realtorfullnameDataGridViewTextBoxColumn"].Value.ToString();
            textBox6.Text = dataGridView2.CurrentRow.Cells["realtorphoneDataGridViewTextBoxColumn"].Value.ToString();
            textBox7.Text = dataGridView2.CurrentRow.Cells["clientfullnameDataGridViewTextBoxColumn"].Value.ToString();
            textBox8.Text = dataGridView2.CurrentRow.Cells["clientphoneDataGridViewTextBoxColumn"].Value.ToString();
            textBox9.Text = dataGridView2.CurrentRow.Cells["transactionamountDataGridViewTextBoxColumn"].Value.ToString();
        }
    }
}

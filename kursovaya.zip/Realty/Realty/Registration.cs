﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Realty
{
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(FirstNametextBox.Text) ||
                string.IsNullOrWhiteSpace(NametextBox.Text) ||
                string.IsNullOrWhiteSpace(PatronymictextBox.Text) ||
                string.IsNullOrWhiteSpace(PhonetextBox.Text) ||
                string.IsNullOrWhiteSpace(LogintextBox.Text) ||
                string.IsNullOrWhiteSpace(PasswordtextBox.Text) ||
                string.IsNullOrWhiteSpace(PasswordConfirmtextBox.Text)) 
            {
                MessageBox.Show("Все поля должны быть заполнены.");
                return;
            }

            // Проверка совпадения паролей
            if (PasswordtextBox.Text != PasswordConfirmtextBox.Text)
            {
                MessageBox.Show("Пароли не совпадают. Попробуйте снова.");
                return;
            }

            SqlConnection conn = new SqlConnection(Properties.Settings.Default.connectionRealty);
            SqlCommand cmd = new SqlCommand("add_user", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            conn.Open();

            cmd.Parameters.AddWithValue("@user_surname", FirstNametextBox.Text);
            cmd.Parameters.AddWithValue("@user_name", NametextBox.Text);
            cmd.Parameters.AddWithValue("@user_patronymic", PatronymictextBox.Text);
            cmd.Parameters.AddWithValue("@user_phone", PhonetextBox.Text);
            cmd.Parameters.AddWithValue("@login", LogintextBox.Text);
            cmd.Parameters.AddWithValue("@password", md5.hashPassword(PasswordtextBox.Text));

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Вы успешно зарегистрировались!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка! " + ex.Message);
            }

            FormAuthorization authorization = new FormAuthorization();
            authorization.Show();
            this.Close();
            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FirstNametextBox.Text = "";
            FirstNametextBox.ForeColor = Color.Gray; 

            NametextBox.Text = "";
            NametextBox.ForeColor = Color.Gray; 

            PatronymictextBox.Text = "";
            PatronymictextBox.ForeColor = Color.Gray; 

            PhonetextBox.Text = "";
            PhonetextBox.ForeColor = Color.Gray; 

            LogintextBox.Text = "";
            LogintextBox.ForeColor = Color.Gray; 

            PasswordtextBox.Text = "";
            PasswordtextBox.ForeColor = Color.Gray;

            PasswordConfirmtextBox.Text = "";
            PasswordConfirmtextBox.ForeColor = Color.Gray;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            FormAuthorization authorization = new FormAuthorization();
            authorization.Show();
        }
    }
}
